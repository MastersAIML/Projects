## Generated Story 5575656197305734
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant
    - slot{"location": null}
* affirm
    - utter_goodbye
    - export
## Generated Story 3884163192287029647
* goodbye
    - utter_greet
* restaurant_search{"cuisine": "indian"}
    - slot{"cuisine": "indian"}
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
* restaurant_search
    - export

