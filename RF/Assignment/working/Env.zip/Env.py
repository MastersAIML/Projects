# Import routines

import numpy as np
import math
import random
import itertools
from itertools import product

# Defining hyperparameters
m = 5  # number of cities, ranges from 1 ..... m
t = 24  # number of hours, ranges from 0 .... t-1
d = 7  # number of days, ranges from 0 ... d-1
C = 5  # Per hour fuel and other costs
R = 9  # per hour revenue from a passenger
# 𝑇𝑖𝑚𝑒−𝑚𝑎𝑡𝑟𝑖𝑥[𝑠𝑡𝑎𝑟𝑡−𝑙𝑜𝑐][𝑒𝑛𝑑−𝑙𝑜𝑐][ℎ𝑜𝑢𝑟−𝑜𝑓−𝑡ℎ𝑒−𝑑𝑎𝑦] [𝑑𝑎𝑦−𝑜𝑓−𝑡ℎ𝑒−𝑤𝑒𝑒𝑘]


class CabDriver():

    def __init__(self):
        """initialise your state and define your action space and state space"""
        self.locations = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E'}
        self.days = np.arange(0, 7)
        self.hours = np.arange(0, 24)
        self.interim_commute_time = 0
        self.total_commute = 0
        self.pickup_drop_time = 0

        self.action_space = [a for a in list(product(self.locations.values(
        ), self.locations.values())) if a[0] != a[1]]  # 20 possible actions
        # extending the action space to have an action of no service
        # self.action_space.extend([(0,0)]) # as in the request the explicit addition of the request been made
        self.n_actions = len(self.action_space)
        # STATE is [location, hours, days]
        self.state_space = [a for a in list(
            product(self.locations.values(), self.hours, self.days))]
        # self.state_init =

        # Start the first round
        # self.reset()

    # Utility functions
    def day_time_changer(self, hour, week_day):
        """Time and week day calculations, it cares of changing the week day based on time """
        while hour >= 24:
            if hour == 24:
                week_day = week_day+1
                hour = 0
            elif hour > 24:
                week_day = week_day+1
                hour = hour-24
            if week_day > 6:
                week_day = week_day-7
        return (hour, week_day)

    def get_dict_keys(self, value):
        """Get the dictionary key based on values """
        key = list(self.locations.keys())[
                   list(self.locations.values()).index(value)]
        return key

    # Encoding state (or state-action) for NN input

    def state_encod_arch1(self, state):
        """convert the state into a vector so that it can be fed to the NN. This method converts a given state into a vector format. Hint: The vector is of size m + t + d."""
        location_vec = np.eye(m, dtype=np.int16)[self.get_dict_keys(state[0])]
        hour_vec = np.eye(t, dtype=np.int16)[state[1]]
        day_vec = np.eye(d, dtype=np.int16)[state[2]]
        state_encod = np.concatenate((location_vec, hour_vec, day_vec))
        return state_encod

    # Use this function if you are using architecture-2

    def state_encod_arch2(self, state, action):
        """convert the (state-action) into a vector so that it can be fed to the NN. This method converts a given state-action pair into a vector format. Hint: The vector is of size m + t + d + m + m."""
        location_vec = np.eye(m, dtype=np.int16)[self.get_dict_keys(state[0])]
        hour_vec = np.eye(t, dtype=np.int16)[state[1]]
        day_vec = np.eye(d, dtype=np.int16)[state[2]]
        # explict checking for action
        if type(action[0] is not str) and type(action[1] is not str):
            a_pickup_vec, a_drop_vec = np.linspace(
                0, 0, m, dtype=np.int), np.linspace(0, 0, m, dtype=np.int)
        else:
            a_pickup_vec = np.eye(m, dtype=np.int16)[
                                  self.get_dict_keys(action[0])]
            a_drop_vec = np.eye(m, dtype=np.int16)[
                                self.get_dict_keys(action[1])]

        state_encod = np.concatenate(
            (location_vec, hour_vec, day_vec, a_pickup_vec, a_drop_vec))
        return state_encod

    # Getting number of requests

    def requests(self, state):
        """Determining the number of requests basis the location.
        Use the table specified in the MDP and complete for rest of the locations"""
        location = state[0]
        if location == 0 or location == 'A':
            requests = np.random.poisson(2)
        elif location == 1 or location == 'B':
            requests = np.random.poisson(12)
        elif location == 2 or location == 'C':
            requests = np.random.poisson(4)
        elif location == 3 or location == 'D':
            requests = np.random.poisson(7)
        elif location == 4 or location == 'E':
            requests = np.random.poisson(8)
        if requests > 15:
            requests = 15

        # (0,0) is not considered as customer request
        possible_actions_index = random.sample(range(1, (m-1)*m + 1), requests)
        actions = [self.action_space[i] for i in possible_actions_index]
        actions.append([0, 0])

        return possible_actions_index, actions

    def reward_func(self, state, action, Time_matrix):
        """Takes in state, action and Time-matrix and returns the reward"""
        # So, the reward function will be(revenue earned from pickup point 𝑝 to drop point 𝑞) - 
        # (Cost of battery used in moving from pickup point 𝑝 to drop point 𝑞) - 
        # (Cost of battery used in moving from current point 𝑖 to pick-up point 𝑝)
        # C = 5  # Per hour fuel and other costs
        # R = 9  # per hour revenue from a passenger
        r1=(self.pickup_drop_time*9)-(self.total_commute*5)
        r2=(self.pickup_drop_time*9)-(self.interim_commute_time*5)-(self.pickup_drop_time*5)
        if r1==r2:
            reward=r1
        else:
            reward=r2
        return reward

    def next_state_func(self, state, action, Time_matrix):
        """Takes state and action as input and returns next state"""
        self.interim_commute_time=0
        self.pickup_drop_time=0
        pickup_location=action[0]
        drop_location=action[1]
        current_location=state[0]
        hour_of_day=state[1]
        day_of_week=state[2]
        if current_location!=pickup_location:
            self.interim_commute_time=Time_matrix[self.get_dict_keys(current_location)][self.get_dict_keys(pickup_location)][hour_of_day][day_of_week]
            hour_of_day=self.interim_commute_time+hour_of_day
            hour_of_day,day_of_week= self.day_time_changer(hour_of_day,day_of_week)
            current_location=pickup_location
        
        self.pickup_drop_time=Time_matrix[self.get_dict_keys(current_location)][self.get_dict_keys(drop_location)][hour_of_day][day_of_week]
        hour_of_day=hour_of_day+self.pickup_drop_time
        hour_of_day,day_of_week= self.day_time_changer(hour_of_day,day_of_week)
    
        self.total_commute=self.total_commute+self.interim_commute_time+self.pickup_drop_time
        next_state=((drop_location,hour_of_day,day_of_week),action)
        return next_state

    def reset(self):
        return self.action_space, self.state_space, self.state_init
